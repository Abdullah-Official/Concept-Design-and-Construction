export const TeamData = [
    {
        name: 'Suleman Shaikh',
        position: 'Director'
    },
    {
        name: 'Adnan Shaikh',
        position: 'CEO'
    },
    {
        name: 'Taimoor Shaikh',
        position: 'Business Manager',
        manager: 'Manager'
    },
]